 poweroff
 poweroff
hostnamectl set-hostname TPServer
hostnamectl
nano /etc/hosts
vi /etc/hosts
vi /etc/hosts
apt install virtualbox-guest-utils -y
apt install virtualbox-guest-x11 -y
apt install build-essential dkms linux-headers-$(uname -r) -y
reboot
poweroff
pwd 
ls -l
cd ...
cd ..
pwds
pwsd
pwd
ls
cd opt
ls
ls -l
clear
mkdir -p /opt/scripts
ls -l /opt
vi /opt/scripts/backup_full.sh
ls -l /opt
ls -l /opt/scripts
clear
vi /opt/scripts/backup_full.sh
ls -l /opt/scripts
ls -l /opt/scripts
clear
ls 
cd scripts/
ls
cat backup_full.sh 
poweroff
